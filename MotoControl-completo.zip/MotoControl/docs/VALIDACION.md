# Validación del MVP

Fecha del informe: 8 de noviembre de 2026 (Buenos Aires).

## Comprobado en este entorno

- Instalados SDK Android Platform 36, Build Tools 36.0.0 y JDK Temurin 17 para compilar. El entorno inicial solo tenía un runtime Java, no `javac` ni SDK Android.
- Compilación del proyecto final con Gradle 8.13: `assembleDebug` correcto.
- `testDebugUnitTest`: **17 pruebas, 0 fallos, 0 errores, 0 omitidas**. Protocolo: 6; procesamiento del joystick: 6; geometría de gestos: 5.
- `lintDebug`: **0 errores, 8 advertencias**. Advertencias sobre actualizaciones disponibles de dependencias/Gradle y compatibilidad de configuración de backup. Se conservan versiones estables fijadas que compilaron juntas. Backup está deshabilitado explícitamente y se incluyen reglas de extracción para Android 12+.
- Firma debug del APK verificada mediante `apksigner verify --verbose` (esquema v2).
- Metadatos del APK comprobados: paquete `dev.motocontrol`, versión 1.0.0, min SDK 26, target SDK 36. No hay permiso `INTERNET` en el APK final.
- SHA-256 de la distribución Gradle contrastado con el publicado por Gradle; wrapper incluye el hash.
- Se entrega Gradle Wrapper completo, con JAR, script Unix ejecutable y script Windows.

Los informes originales están en `docs/verification/`. Las pruebas de geometría comprueban ambos modos, diagonales, extremos dentro de la región, sentido del zoom y límite de duración. Las pruebas del protocolo incluyen fragmentación, múltiples tramas, bytes corruptos, límites y recuperación. Las de joystick incluyen zona muerta, reposo inmediato, sensibilidad proporcional, normalización diagonal, inversión, suavizado y antirrebote.

## No probado en un dispositivo

**No se instaló ni ejecutó el APK en un teléfono o emulador durante este trabajo. No hubo un ESP32 conectado.** No se afirma que la aceptación en hardware esté completada. No se ha validado Google Maps ni una ruta activa en versiones concretas de Android/Maps.

## Checklist de aceptación en teléfono y ESP32

- [ ] Instalar y abrir el APK, conceder permisos según versión Android.
- [ ] Habilitar accesibilidad manualmente y comprobar el estado mostrado.
- [ ] Iniciar demo, desactivar restricción solo para prueba local, activar control y probar joystick virtual.
- [ ] Confirmar desplazamiento horizontal, vertical y diagonal sobre Maps con prueba programada.
- [ ] Confirmar zoom con dos dedos, cambio de modo con pulsación y ausencia de cambios repetidos al mantener el botón.
- [ ] Con la restricción activada, verificar bloqueo de gestos fuera de Maps y al mostrar System UI, pantallas del sistema o una app no autorizada.
- [ ] Bloquear/apagar el teléfono y verificar ausencia de nuevos gestos.
- [ ] Escanear el ESP32, descubrir GATT, suscribirse y comprobar datos a 20–30 Hz.
- [ ] Controlar Maps con joystick físico mientras MotoControl permanece en segundo plano.
- [ ] Cortar notificaciones manteniendo el enlace: después de 500 ms sin muestra válida no deben iniciarse nuevos movimientos (más latencia de comprobación y finalización del gesto en curso).
- [ ] Soltar joystick, pulsar Detener y cortar el enlace BLE: comprobar que no se acumulan gestos y que la reconexión exige reactivar manualmente el control.
- [ ] Verificar parada desde la notificación y cierre al quitar la tarea de recientes.
- [ ] Probar giro de pantalla, márgenes grandes, navegación por gestos/botones y comportamiento de batería del fabricante.
- [ ] Comprobar funcionamiento durante una ruta real de Maps con la moto detenida, sin asumir que todas sus vistas admiten arrastre o zoom.

Cada gesto dura hasta 350 ms. La API pública no permite una cancelación sin contacto del gesto activo: la parada impide inmediatamente los siguientes, pero el actual puede finalizar. Los paquetes de ventanas se identifican mediante eventos, sin leer contenido; el estado desconocido bloquea el control. No usar overlays ni multiventana durante las pruebas/control. Consulta las limitaciones completas en README.

# Protocolo MotoControl BLE · versión 1

## GATT

ESP32 Peripheral; Android Central. Nombre recomendado: `MotoControl ESP32` (exacto si se activa el filtro).

| Elemento | UUID | Propiedades |
|---|---|---|
| Servicio | `6d6f746f-6374-4c00-8000-000000000001` | primario personalizado |
| Entrada | `6d6f746f-6374-4c00-8000-000000000002` | NOTIFY |
| CCCD | `00002902-0000-1000-8000-00805f9b34fb` | descriptor, Android escribe `01 00` |

Incluye el UUID del servicio en advertising y el nombre en advertising/scan response. Android descubre servicios, habilita notificaciones y escribe CCCD antes de declarar la conexión lista. No hace lecturas/escrituras adicionales ni negocia MTU: las tramas JOY máximas caben en los 20 bytes de carga del ATT MTU 23.

## Trama

ASCII, una línea acabada en LF (`0x0A`), CRLF también aceptado. Sin espacios, enteros decimales:

```text
V1,JOY,2048,2048,0\n
V1,JOY,4095,0,1\n
```

`\n` representa un byte LF real, no los caracteres barra y n. En Arduino C++: `snprintf(buffer, sizeof(buffer), "V1,JOY,%d,%d,%d\n", x, y, pressed ? 1 : 0);` seguido de `setValue(...)` y `notify()` en la característica.

| Campo | Valores |
|---|---|
| Versión | `V1` |
| Tipo | `JOY` |
| X | 0–4095, centro 2048, positivo derecha |
| Y | 0–4095, centro 2048, positivo abajo |
| Botón | `0` suelto / `1` pulsado |

Compatibilidad inicial: `JOY,2048,2048,0` también se admite, **siempre terminado con LF**. No enviar muestras sin delimitador: el receptor no puede distinguir una muestra completa de una fragmentada. El comando más largo de V1 JOY ocupa 19 bytes incluido LF, apto para una notificación estándar.

Envía a 25 Hz (40 ms), incluso en reposo. Solo envía mientras haya suscripción. No es un protocolo de eventos de flanco: el botón transmite su estado en cada muestra. Android alterna modo en flanco ascendente, con antirrebote de 250 ms. Aplicar también antirrebote físico en firmware. Cambiar de MAPA/ZOOM no se confirma al ESP32 en esta versión.

## Fragmentación, errores y pérdida de enlace

El decoder recibe fragmentos arbitrarios y puede extraer varias líneas de una notificación. Acumula como máximo 80 caracteres. Una línea demasiado larga o con bytes no admitidos se descarta hasta el próximo LF. Una línea con campos incompletos, rango incorrecto, versión desconocida o tipo no soportado se rechaza sin renovar el timeout. Una trama fragmentada se retiene hasta LF; sin datos válidos durante 500 ms el motor pasa a reposo. Al desconectarse se limpia el decoder y se desarma el control.

BLE conserva orden dentro de la conexión, pero no se asume entrega infalible. No se reconstruyen comandos antiguos ni se reproducen movimientos tras una reconexión. No hay ACK a nivel de aplicación ni colas de movimiento. La app debe recibir muestras nuevas después de activarse manualmente.

## Extensiones reservadas

El campo tipo permite introducir en una siguiente versión:

```text
V1,ENC,+1\n
V1,BTN,2,1\n
V1,BAT,85\n
```

Estas tres tramas están **reservadas, no implementadas** en el MVP y actualmente se rechazan de forma segura. Para incorporarlas añade modelos tipados y validadores antes de emitirlas desde firmware; no sobrecargues campos JOY ni cambies sus rangos. Un cambio incompatible exige `V2`. Evita transmitir tipos reservados continuamente con este receptor para no llenar su registro de errores.

## Esquema de firmware Arduino C++

1. Configura ADC de 12 bits y calibra el centro eléctrico hacia 2048. Los pines ADC concretos dependen de tu placa ESP32.
2. Configura pulsador con pull-up; convierte LOW en `pressed=1`.
3. Crea el servicio/UUID anteriores y característica NOTIFY con CCCD (NimBLE puede gestionar el descriptor automáticamente según versión).
4. Inicia advertising con nombre y UUID, reinícialo al desconectarse.
5. Cada 40 ms lee ADC, limita 0–4095, formatea la línea ASCII y notifica si hay cliente suscrito. Usa un planificador por `millis()` que no acumule retrasos.
6. Mantén las muestras en reposo para el heartbeat y deja de notificar al desconectarse.

Este documento es la especificación para desarrollar el firmware; no se entrega un firmware validado en placa ni se fija una librería ESP32 particular.

package dev.motocontrol.service

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import dev.motocontrol.MotoApplication
import dev.motocontrol.R
import dev.motocontrol.ui.MainActivity
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first

class ControlService: Service() {
 companion object { const val STOP="dev.motocontrol.STOP"; const val DEMO="demo" }
 private val graph get()=(application as MotoApplication).graph
 private val handler=Handler(Looper.getMainLooper())
 private val tick=object: Runnable { override fun run() { graph.engine.tick(); handler.postDelayed(this,if(graph.engine.armed.value) 25 else 250) } }
 override fun onCreate() { super.onCreate(); createChannel() }
 override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
  if(intent?.action==STOP) { shutdown(); return START_NOT_STICKY }
  try {
   val notification=notification()
   if(Build.VERSION.SDK_INT>=29) startForeground(1,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE) else startForeground(1,notification)
  } catch(e: Exception) { graph.diagnostics.fail("No se pudo iniciar servicio: ${e.message}"); shutdown(); return START_NOT_STICKY }
  val newDemo=intent?.getBooleanExtra(DEMO,false) ?: false
  if(!graph.serviceRunning.value || graph.demo.value!=newDemo) {
   graph.stop("Sesión iniciada; activa el control")
   graph.ble.disconnect(); graph.demo.value=newDemo
  }
  graph.serviceRunning.value=true
  handler.removeCallbacks(tick); handler.post(tick)
  if(!newDemo) graph.scope.launch {
   graph.settings.initialized.first { it }
   if(graph.serviceRunning.value && !graph.demo.value) graph.ble.reconnectLast()
  }
  return START_NOT_STICKY
 }
 private fun createChannel() {
  getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("control","Control BLE activo",NotificationManager.IMPORTANCE_LOW))
 }
 private fun notification(): Notification {
  val flags=PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
  val open=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),flags)
  val stop=PendingIntent.getService(this,1,Intent(this,ControlService::class.java).setAction(STOP),flags)
  return Notification.Builder(this,"control").setSmallIcon(R.drawable.ic_moto).setContentTitle("MotoControl · sesión activa")
   .setContentText("BLE en segundo plano. Detener desactiva el control y la conexión.").setOngoing(true).setContentIntent(open)
   .addAction(Notification.Action.Builder(null,"Detener",stop).build()).build()
 }
 private fun shutdown() {
  graph.stop("Sesión detenida"); graph.ble.disconnect(); graph.serviceRunning.value=false
  handler.removeCallbacksAndMessages(null); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
 }
 override fun onTaskRemoved(rootIntent: Intent?) { shutdown(); super.onTaskRemoved(rootIntent) }
 override fun onDestroy() { handler.removeCallbacksAndMessages(null); graph.stop("Servicio cerrado"); graph.ble.disconnect(); graph.serviceRunning.value=false; super.onDestroy() }
 override fun onBind(intent: Intent?) = null
}

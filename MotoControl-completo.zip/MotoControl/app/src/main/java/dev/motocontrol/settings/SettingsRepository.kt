package dev.motocontrol.settings

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.*
import java.io.IOException

private val Context.dataStore by preferencesDataStore("motocontrol")
data class ControlSettings(
 val minSpeed: Float = 15f, val maxSpeed: Float = 160f, val sensitivity: Float = 1f,
 val deadZone: Float = .12f, val smoothing: Float = .3f,
 val invertX: Boolean = false, val invertY: Boolean = false,
 val frequency: Float = 6f, val duration: Float = 140f,
 val top: Float = 100f, val bottom: Float = 140f, val side: Float = 48f,
 val zoomSensitivity: Float = 1f, val zoomAmplitude: Float = 90f, val zoomDuration: Float = 180f,
 val mapsOnly: Boolean = true, val reconnect: Boolean = true, val lastAddress: String = ""
)
class SettingsRepository(context: Context, scope: CoroutineScope) {
 private val store = context.dataStore
 val initialized = MutableStateFlow(false)
 private fun Preferences.f(key: String, default: Float) = this[floatPreferencesKey(key)] ?: default
 private fun Preferences.b(key: String, default: Boolean) = this[booleanPreferencesKey(key)] ?: default
 val state = store.data.catch { if (it is IOException) emit(emptyPreferences()) else throw it }.map { p ->
  ControlSettings(p.f("minSpeed",15f).coerceIn(1f,80f),p.f("maxSpeed",160f).coerceIn(80f,300f),
   p.f("sensitivity",1f).coerceIn(.3f,2f),p.f("deadZone",.12f).coerceIn(.02f,.4f),p.f("smoothing",.3f).coerceIn(0f,.85f),
   p.b("invertX",false),p.b("invertY",false),p.f("frequency",6f).coerceIn(1f,12f),p.f("duration",140f).coerceIn(60f,350f),
   p.f("top",100f).coerceIn(40f,300f),p.f("bottom",140f).coerceIn(40f,300f),p.f("side",48f).coerceIn(24f,180f),
   p.f("zoomSensitivity",1f).coerceIn(.3f,2f),p.f("zoomAmplitude",90f).coerceIn(20f,180f),p.f("zoomDuration",180f).coerceIn(60f,350f),
   p.b("mapsOnly",true),p.b("reconnect",true),p[stringPreferencesKey("lastAddress")] ?: "")
 }.onEach { initialized.value=true }.stateIn(scope, SharingStarted.Eagerly, ControlSettings())
 suspend fun number(key: String, value: Float) { store.edit { it[floatPreferencesKey(key)] = value } }
 suspend fun toggle(key: String, value: Boolean) { store.edit { it[booleanPreferencesKey(key)] = value } }
 suspend fun remember(address: String) { store.edit { it[stringPreferencesKey("lastAddress")] = address } }
}

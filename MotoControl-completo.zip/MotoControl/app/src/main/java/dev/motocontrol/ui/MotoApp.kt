package dev.motocontrol.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.motocontrol.ble.JoystickFrame
import dev.motocontrol.input.ControlMode
import kotlin.math.*

private val Mint=Color(0xFF64E5BD)
@Composable fun MotoApp(vm: MainViewModel,session: (Boolean)->Unit,end: ()->Unit,accessibility: ()->Unit,bluetooth: ()->Unit,maps: ()->Unit) {
 val scheme=darkColorScheme(primary=Mint,background=Color(0xFF0B1519),surface=Color(0xFF152329),secondary=Color(0xFF9FC8FF),error=Color(0xFFFFB4AB))
 MaterialTheme(colorScheme=scheme) {
  var tab by remember { mutableIntStateOf(0) }
  Scaffold(bottomBar={ NavigationBar { listOf("Control","Ajustes","Diagnóstico").forEachIndexed { index,title ->
   NavigationBarItem(selected=tab==index,onClick={tab=index},icon={Text(listOf("◎","⚙","≋")[index],fontSize=24.sp)},label={Text(title)})
  } } }) { padding ->
   Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal=20.dp,vertical=18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
    Text("MOTO / CONTROL",color=Mint,style=MaterialTheme.typography.labelLarge)
    Text(listOf("Tu mapa, al mando.","A tu manera.","Todo bajo control.")[tab],style=MaterialTheme.typography.headlineLarge)
    Text("Control remoto BLE · v1.0",color=MaterialTheme.colorScheme.onSurfaceVariant)
    when(tab) { 0 -> ControlScreen(vm,session,end,accessibility,bluetooth,maps); 1 -> SettingsScreen(vm); else -> DiagnosticsScreen(vm) }
    Text("Configura y prueba con la moto detenida. Mantén la atención en la conducción.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
   }
  }
 }
}
@Composable private fun Panel(title: String,content: @Composable ColumnScope.()->Unit) {
 Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(22.dp)) { Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
  Text(title,style=MaterialTheme.typography.titleMedium); content()
 } }
}
@Composable private fun ControlScreen(vm: MainViewModel,session: (Boolean)->Unit,end: ()->Unit,accessibility: ()->Unit,bluetooth: ()->Unit,maps: ()->Unit) {
 val g=vm.graph
 val status by g.ble.status.collectAsStateWithLifecycle()
 val connected by g.ble.connected.collectAsStateWithLifecycle()
 val radio by g.ble.bluetoothOn.collectAsStateWithLifecycle()
 val name by g.ble.deviceName.collectAsStateWithLifecycle()
 val service by g.serviceRunning.collectAsStateWithLifecycle()
 val access by g.accessibility.collectAsStateWithLifecycle()
 val demo by g.demo.collectAsStateWithLifecycle()
 val armed by g.engine.armed.collectAsStateWithLifecycle()
 val mode by g.engine.mode.collectAsStateWithLifecycle()
 val reason by g.engine.reason.collectAsStateWithLifecycle()
 val raw by g.latest.collectAsStateWithLifecycle()
 val devices by g.ble.devices.collectAsStateWithLifecycle()
 val scanning by g.ble.scanning.collectAsStateWithLifecycle()
 val config by g.settings.state.collectAsStateWithLifecycle()
 var filter by remember { mutableStateOf(true) }
 Panel("Conexión y permisos") {
  Text(if(service && demo) "● Sesión de demostración" else "${if(connected) "●" else "○"} $status",color=if(connected || (service && demo)) Mint else MaterialTheme.colorScheme.onSurface)
  if(name.isNotEmpty()) Text(name)
  Text("Bluetooth: ${if(radio) "encendido" else "apagado, no disponible o sin permisos"}")
  Text("Accesibilidad: ${if(access) "habilitada" else "deshabilitada"}")
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
   OutlinedButton(onClick=bluetooth,modifier=Modifier.weight(1f)) { Text("Bluetooth") }
   OutlinedButton(onClick=accessibility,modifier=Modifier.weight(1f)) { Text("Accesibilidad") }
  }
  Text("Accesibilidad genera arrastres y zoom sin leer contenido. Habilítala manualmente en Ajustes. El control empieza detenido.",style=MaterialTheme.typography.bodySmall)
  if(!service) {
   Button(onClick={session(false)},modifier=Modifier.fillMaxWidth()) { Text("Iniciar sesión BLE") }
   OutlinedButton(onClick={session(true)},modifier=Modifier.fillMaxWidth()) { Text("Probar sin ESP32") }
  } else {
   OutlinedButton(onClick=end,modifier=Modifier.fillMaxWidth()) { Text("Cerrar sesión y desconectar") }
   if(!demo) {
    SettingSwitch("Filtrar MotoControl ESP32",filter) { filter=it }
    Button(onClick={g.ble.scan(filter)},enabled=!scanning,modifier=Modifier.fillMaxWidth()) { Text(if(scanning) "Buscando durante 15 s…" else "Escanear dispositivos") }
    if(connected) OutlinedButton(onClick={g.ble.disconnect()}) { Text("Desconectar ESP32") }
    devices.forEach { d ->
     OutlinedButton(onClick={g.ble.connect(d.address)},modifier=Modifier.fillMaxWidth()) {
      Column(Modifier.fillMaxWidth()) { Text(d.name); Text("${d.address} · ${d.rssi} dBm",style=MaterialTheme.typography.bodySmall) }
     }
    }
    if(!scanning && devices.isEmpty()) Text("Inicia el escaneo. Android 8–11 necesita Ubicación activada.",style=MaterialTheme.typography.bodySmall)
   }
  }
 }
 Panel("${if(armed) "● CONTROL ACTIVO" else "○ CONTROL DETENIDO"} · ${mode.name}") {
  Text(reason,color=Mint)
  Text(if(config.mapsOnly) "Solo Google Maps · región segura" else "Maps y demo local autorizados")
  if(!armed) Button(onClick={g.engine.arm()},enabled=service && access && (demo || connected),modifier=Modifier.fillMaxWidth()) { Text("Activar control explícitamente") }
  Button(onClick=vm::stop,colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.errorContainer,contentColor=MaterialTheme.colorScheme.onErrorContainer),modifier=Modifier.fillMaxWidth().heightIn(min=56.dp)) { Text("■  DETENER CONTROL") }
  Text("Parada: no se envían nuevos gestos. El actual puede terminar en hasta 350 ms.",style=MaterialTheme.typography.bodySmall)
  OutlinedButton(onClick=maps,modifier=Modifier.fillMaxWidth()) { Text("Abrir Google Maps") }
 }
 Panel(if(demo && service) "Joystick virtual" else "Joystick · datos en vivo") {
  Joystick(raw,enabled=demo && service,onMove=vm::hold,onRelease=vm::release)
  Text("X ${raw.x}   /   Y ${raw.y}   /   Botón ${if(raw.pressed) 1 else 0}",modifier=Modifier.align(Alignment.CenterHorizontally))
  if(demo && service) {
   OutlinedButton(onClick=vm::toggleMode,modifier=Modifier.fillMaxWidth()) { Text("Pulsar joystick · cambiar MAPA / ZOOM") }
   Text("Prueba local: desactiva «Solo Google Maps» en Ajustes. Para probar sobre Maps, activa el control, elige una prueba y abre Maps durante los 3 segundos de espera.",style=MaterialTheme.typography.bodySmall)
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
    OutlinedButton(onClick={vm.test(0f,-.7f,3000)},enabled=armed,modifier=Modifier.weight(1f)) { Text(if(mode==ControlMode.ZOOM) "Acercar · 3 s" else "Arriba · 3 s") }
    OutlinedButton(onClick={vm.test(0f,.7f,3000)},enabled=armed,modifier=Modifier.weight(1f)) { Text(if(mode==ControlMode.ZOOM) "Alejar · 3 s" else "Abajo · 3 s") }
   }
   if(mode==ControlMode.MAPA) Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
    OutlinedButton(onClick={vm.test(-.7f,0f,3000)},enabled=armed,modifier=Modifier.weight(1f)) { Text("Izquierda · 3 s") }
    OutlinedButton(onClick={vm.test(.7f,0f,3000)},enabled=armed,modifier=Modifier.weight(1f)) { Text("Derecha · 3 s") }
   }
  }
 }
}
@Composable private fun Joystick(raw: JoystickFrame,enabled: Boolean,onMove: (Float,Float)->Unit,onRelease: ()->Unit) {
 val move by rememberUpdatedState(onMove)
 val release by rememberUpdatedState(onRelease)
 Canvas(Modifier.fillMaxWidth().height(220.dp).semantics { contentDescription="Joystick virtual. Arrastra para mover, suelta para detener." }.pointerInput(enabled) {
  if(enabled) detectDragGestures(onDragStart={ position ->
   val radius=min(size.width,size.height)*.39f; val v=position-Offset(size.width/2f,size.height/2f)
   val scale=max(1f,v.getDistance()/radius); move(v.x/radius/scale,v.y/radius/scale)
  },onDragEnd={release()},onDragCancel={release()}) { change,_ ->
   change.consume(); val radius=min(size.width,size.height)*.39f
   val v=change.position-Offset(size.width/2f,size.height/2f); val scale=max(1f,v.getDistance()/radius)
   move(v.x/radius/scale,v.y/radius/scale)
  }
 }) {
  val radius=min(size.width,size.height)*.39f
  val center=Offset(size.width/2,size.height/2)
  drawCircle(Color(0xFF0B1519),radius,center); drawCircle(Mint.copy(alpha=.22f),radius,center,style=Stroke(2f))
  drawCircle(Mint.copy(alpha=.12f),radius*.5f,center,style=Stroke(1f))
  drawLine(Mint.copy(alpha=.18f),center-Offset(radius,0f),center+Offset(radius,0f))
  drawLine(Mint.copy(alpha=.18f),center-Offset(0f,radius),center+Offset(0f,radius))
  val position=center+Offset((raw.x-2048)/2048f*radius,(raw.y-2048)/2048f*radius)
  drawCircle(Mint.copy(alpha=.15f),28.dp.toPx(),position); drawCircle(Mint,17.dp.toPx(),position)
 }
}
@Composable private fun SettingSwitch(label: String,value: Boolean,onChange: (Boolean)->Unit) {
 Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Text(label,Modifier.weight(1f)); Switch(checked=value,onCheckedChange=onChange) }
}
@Composable private fun SettingSlider(label: String,key: String,value: Float,range: ClosedFloatingPointRange<Float>,vm: MainViewModel,decimals: Boolean=false) {
 var local by remember(value) { mutableFloatStateOf(value) }
 Text("$label · ${if(decimals) "%.2f".format(local) else local.toInt().toString()}",style=MaterialTheme.typography.bodyMedium)
 Slider(value=local,onValueChange={local=it},valueRange=range,onValueChangeFinished={vm.number(key,local)})
}
@Composable private fun SettingsScreen(vm: MainViewModel) {
 val s by vm.graph.settings.state.collectAsStateWithLifecycle()
 Panel("Respuesta del joystick") {
  SettingSlider("Desplazamiento mínimo (dp/gesto)","minSpeed",s.minSpeed,1f..80f,vm)
  SettingSlider("Desplazamiento máximo (dp/gesto)","maxSpeed",s.maxSpeed,80f..300f,vm)
  SettingSlider("Sensibilidad","sensitivity",s.sensitivity,.3f..2f,vm,true)
  SettingSlider("Zona muerta (fracción)","deadZone",s.deadZone,0.02f..0.4f,vm,true)
  SettingSlider("Suavizado (0 = desactivado)","smoothing",s.smoothing,0f..0.85f,vm,true)
  SettingSwitch("Invertir eje X",s.invertX) { vm.toggle("invertX",it) }
  SettingSwitch("Invertir eje Y",s.invertY) { vm.toggle("invertY",it) }
 }
 Panel("Gestos y región segura") {
  SettingSlider("Frecuencia máxima (gestos/s)","frequency",s.frequency,1f..12f,vm)
  SettingSlider("Duración arrastre (ms)","duration",s.duration,60f..350f,vm)
  SettingSlider("Margen superior (dp)","top",s.top,40f..300f,vm)
  SettingSlider("Margen inferior (dp)","bottom",s.bottom,40f..300f,vm)
  SettingSlider("Margen lateral (dp)","side",s.side,24f..180f,vm)
  Text("Cada arrastre libera el contacto. Una pantalla demasiado pequeña para los márgenes bloquea los gestos.",style=MaterialTheme.typography.bodySmall)
 }
 Panel("Zoom de dos dedos") {
  SettingSlider("Sensibilidad de zoom","zoomSensitivity",s.zoomSensitivity,.3f..2f,vm,true)
  SettingSlider("Amplitud zoom (dp)","zoomAmplitude",s.zoomAmplitude,20f..180f,vm)
  SettingSlider("Duración zoom (ms)","zoomDuration",s.zoomDuration,60f..350f,vm)
 }
 Panel("Protección y conexión") {
  SettingSwitch("Solo Google Maps (recomendado)",s.mapsOnly) { vm.stop(); vm.toggle("mapsOnly",it) }
  Text("Desactivarlo permite además pruebas sobre MotoControl. Nunca se autorizan otras aplicaciones ni interfaces del sistema. Si no puede identificarse la app activa, se bloquean los gestos.",style=MaterialTheme.typography.bodySmall)
  SettingSwitch("Reconectar automáticamente",s.reconnect) { vm.toggle("reconnect",it) }
  Text("La reconexión nunca reactiva el control. Tras una desconexión, actívalo de nuevo manualmente.",style=MaterialTheme.typography.bodySmall)
 }
}
@Composable private fun DiagnosticsScreen(vm: MainViewModel) {
 val g=vm.graph
 val raw by g.latest.collectAsStateWithLifecycle()
 val status by g.ble.status.collectAsStateWithLifecycle()
 val last by g.diagnostics.lastMessage.collectAsStateWithLifecycle()
 val gesture by g.diagnostics.lastGesture.collectAsStateWithLifecycle()
 val rate by g.diagnostics.rate.collectAsStateWithLifecycle()
 val error by g.diagnostics.error.collectAsStateWithLifecycle()
 val access by g.accessibility.collectAsStateWithLifecycle()
 val events by g.diagnostics.events.collectAsStateWithLifecycle()
 Panel("Telemetría") {
  Text("BLE: $status\nAccesibilidad: ${if(access) "habilitada" else "deshabilitada"}\nX: ${raw.x} · Y: ${raw.y} · Botón: ${raw.pressed}\nMensajes BLE válidos/s: $rate")
  Text("Último mensaje BLE: $last")
  Text("Último gesto: $gesture")
  if(error.isNotEmpty()) Text("Último error: $error",color=MaterialTheme.colorScheme.error)
 }
 Panel("Registro · últimos 120 eventos") {
  if(events.isEmpty()) Text("Sin eventos todavía")
  events.forEach { Text(it,style=MaterialTheme.typography.bodySmall) }
 }
}

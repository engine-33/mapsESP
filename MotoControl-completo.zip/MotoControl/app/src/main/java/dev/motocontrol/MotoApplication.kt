package dev.motocontrol

import android.app.Application
import android.os.SystemClock
import dev.motocontrol.ble.*
import dev.motocontrol.diagnostics.Diagnostics
import dev.motocontrol.gestures.GestureEngine
import dev.motocontrol.settings.SettingsRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow

class MotoApplication : Application() {
 lateinit var graph: AppGraph; private set
 override fun onCreate() { super.onCreate(); graph = AppGraph(this) }
}
class AppGraph(val app: Application) {
 val scope = CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
 val diagnostics = Diagnostics()
 val settings = SettingsRepository(app,scope)
 val demo = MutableStateFlow(false)
 val serviceRunning = MutableStateFlow(false)
 val accessibility = MutableStateFlow(false)
 val latest = MutableStateFlow(JoystickFrame(2048,2048,false))
 val engine = GestureEngine(this)
 val ble = BleManager(this)
 private var count = 0
 private var rateTime = SystemClock.elapsedRealtime()
 fun receive(frame: JoystickFrame, line: String, virtual: Boolean) {
  if(virtual != demo.value) return
  latest.value = frame
  if(!virtual) {
   diagnostics.lastMessage.value = line.take(100); count++
  }
  engine.input(frame)
 }
 fun sampleRate() {
  val now = SystemClock.elapsedRealtime()
  if(now-rateTime >= 1000) {
   diagnostics.rate.value = (count*1000L/(now-rateTime)).toInt(); count=0; rateTime=now
  }
 }
 fun stop(reason: String) { engine.stop(reason); latest.value=JoystickFrame(2048,2048,false) }
}

package dev.motocontrol.diagnostics

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Diagnostics {
 private val mutable = MutableStateFlow<List<String>>(emptyList())
 val events = mutable.asStateFlow()
 var lastMessage = MutableStateFlow("Sin datos")
 var lastGesture = MutableStateFlow("Ninguno")
 var rate = MutableStateFlow(0)
 var error = MutableStateFlow("")
 @Synchronized fun log(message: String) {
  val time = SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(Date())
  mutable.value = (listOf("$time  $message") + mutable.value).take(120)
 }
 fun fail(message: String) { error.value = message; log(message) }
}

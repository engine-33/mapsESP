package dev.motocontrol.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.motocontrol.MotoApplication
import dev.motocontrol.ble.JoystickFrame
import kotlinx.coroutines.*

class MainViewModel(application: Application): AndroidViewModel(application) {
 val graph=(application as MotoApplication).graph
 private var virtualJob: Job?=null
 private var testJob: Job?=null
 fun hold(x: Float,y: Float) {
  if(!graph.demo.value) return
  testJob?.cancel(); testJob=null
  virtualJob?.cancel()
  val frame=JoystickFrame((2048+x*2047).toInt().coerceIn(0,4095),(2048+y*2047).toInt().coerceIn(0,4095),false)
  virtualJob=viewModelScope.launch { while(isActive) { graph.receive(frame,"VIRTUAL",true); delay(33) } }
 }
 fun release() { virtualJob?.cancel(); virtualJob=null; if(graph.demo.value) graph.receive(JoystickFrame(2048,2048,false),"VIRTUAL",true) }
 fun toggleMode() {
  testJob?.cancel(); testJob=null
  release(); graph.receive(JoystickFrame(2048,2048,true),"VIRTUAL",true)
  graph.receive(JoystickFrame(2048,2048,false),"VIRTUAL",true)
 }
 fun test(x: Float,y: Float, delayMs: Long=0) {
  if(!graph.demo.value || !graph.engine.armed.value) { graph.diagnostics.fail("Inicia una sesión demo y activa el control antes de probar"); return }
  testJob?.cancel(); release()
  testJob=viewModelScope.launch {
   try {
    if(delayMs>0) { graph.diagnostics.log("Prueba en 3 segundos: abre Maps ahora"); delay(delayMs) }
    val frame=JoystickFrame((2048+x*2047).toInt().coerceIn(0,4095),(2048+y*2047).toInt().coerceIn(0,4095),false)
    repeat(30) { if(!graph.engine.armed.value) return@launch; graph.receive(frame,"PRUEBA",true); delay(33) }
   } finally { graph.receive(JoystickFrame(2048,2048,false),"PRUEBA",true) }
  }
 }
 fun stop() { testJob?.cancel(); release(); graph.stop("Parada manual") }
 fun number(key: String,value: Float) { viewModelScope.launch { graph.settings.number(key,value) } }
 fun toggle(key: String,value: Boolean) { viewModelScope.launch { graph.settings.toggle(key,value) } }
 override fun onCleared() { stop(); super.onCleared() }
}

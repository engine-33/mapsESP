package dev.motocontrol.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import dev.motocontrol.service.ControlService

class MainActivity: ComponentActivity() {
 private val vm: MainViewModel by viewModels()
 private var pendingDemo=false
 private val permissions=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
  if(vm.graph.ble.permitted()) launchSession(pendingDemo) else vm.graph.diagnostics.fail("Permisos Bluetooth/Ubicación no concedidos. Revísalos en Ajustes.")
 }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { MotoApp(vm,::session,::endSession,
   { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
   { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
   { val intent=packageManager.getLaunchIntentForPackage("com.google.android.apps.maps"); if(intent!=null) startActivity(intent) else vm.graph.diagnostics.fail("Google Maps no está instalado") }) }
 }
 private fun session(demo: Boolean) {
  vm.stop(); pendingDemo=demo
  val required=if(Build.VERSION.SDK_INT>=31) mutableListOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT)
   else mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
  if(Build.VERSION.SDK_INT>=33) required.add(Manifest.permission.POST_NOTIFICATIONS)
  permissions.launch(required.toTypedArray())
 }
 private fun launchSession(demo: Boolean) {
  try { startForegroundService(Intent(this,ControlService::class.java).putExtra(ControlService.DEMO,demo)) }
  catch(e: Exception) { vm.graph.diagnostics.fail("No se pudo iniciar sesión: ${e.message}") }
 }
 private fun endSession() { vm.stop(); stopService(Intent(this,ControlService::class.java)) }
 override fun onResume() { super.onResume(); vm.graph.ble.refreshBluetooth() }
 override fun onStop() { vm.release(); super.onStop() }
}

package dev.motocontrol.input

import dev.motocontrol.ble.JoystickFrame
import dev.motocontrol.settings.ControlSettings
import kotlin.math.*

data class Motion(val x: Float = 0f, val y: Float = 0f)
enum class ControlMode { MAPA, ZOOM }
class JoystickProcessor {
 private var filtered = Motion()
 private var down = false
 private var lastEdge = Long.MIN_VALUE / 2
 var mode = ControlMode.MAPA; private set
 fun reset() { filtered = Motion(); down = false; lastEdge = Long.MIN_VALUE / 2 }
 fun process(frame: JoystickFrame, settings: ControlSettings, now: Long): Motion {
  if(frame.pressed && !down && now-lastEdge >= 250) {
   mode = if(mode == ControlMode.MAPA) ControlMode.ZOOM else ControlMode.MAPA
   lastEdge = now
  }
  down = frame.pressed
  var x = ((frame.x-2048)/2048f).coerceIn(-1f,1f)
  var y = ((frame.y-2048)/2048f).coerceIn(-1f,1f)
  val magnitude = sqrt(x*x+y*y).coerceAtMost(1f)
  if(magnitude <= settings.deadZone) { filtered = Motion(); return filtered }
  val length = sqrt(x*x+y*y)
  val power = (((magnitude-settings.deadZone)/(1-settings.deadZone))*settings.sensitivity).coerceIn(0f,1f)
  x = x/length*power*(if(settings.invertX) -1 else 1)
  y = y/length*power*(if(settings.invertY) -1 else 1)
  val a = settings.smoothing
  filtered = Motion(filtered.x*a+x*(1-a), filtered.y*a+y*(1-a))
  return filtered
 }
}

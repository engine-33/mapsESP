package dev.motocontrol.accessibility

import android.accessibilityservice.*
import android.app.KeyguardManager
import android.graphics.*
import android.os.*
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import dev.motocontrol.MotoApplication
import dev.motocontrol.input.*
import dev.motocontrol.gestures.GesturePlanner
import dev.motocontrol.gestures.SafeBounds
import dev.motocontrol.settings.ControlSettings
import kotlin.math.*

class MotoAccessibilityService: AccessibilityService() {
 companion object { var instance: MotoAccessibilityService?=null; private set }
 private val graph get()=(application as MotoApplication).graph
 private var foreground: String?=null
 override fun onServiceConnected() {
  instance=this; graph.accessibility.value=true; foreground=null
  graph.diagnostics.log("Accesibilidad disponible; esperando identificar la aplicación activa")
 }
 override fun onAccessibilityEvent(event: AccessibilityEvent?) {
  if(event==null) return
  if(event.eventType==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
   // Unknown and overlays fail closed. No node tree or text is read.
   foreground=event.packageName?.toString()
  } else if(event.eventType==AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
   // Cannot prove foreground from a windows-changed event without retrieving content.
   foreground=null
  }
 }
 fun blockReason(mapsOnly: Boolean): String? {
  val power=getSystemService(PowerManager::class.java)
  if(!power.isInteractive || getSystemService(KeyguardManager::class.java).isKeyguardLocked) return "Pantalla apagada o bloqueada"
  val pkg=foreground ?: return "Aplicación activa desconocida; vuelve a abrir Google Maps"
  if(mapsOnly && pkg!="com.google.android.apps.maps") return "Esperando Google Maps en primer plano"
  val allowed=if(mapsOnly) setOf("com.google.android.apps.maps") else setOf("com.google.android.apps.maps",packageName)
  if(pkg !in allowed) return "Aplicación no autorizada (solo Maps y demostración local)"
  return null
 }
 private fun safeRect(config: ControlSettings): RectF? {
  val wm=getSystemService(WindowManager::class.java)
  val density=resources.displayMetrics.density
  var left=0f; var top=0f; var right=0f; var bottom=0f
  val width: Int; val height: Int
  if(Build.VERSION.SDK_INT>=30) {
   val metrics=wm.currentWindowMetrics; width=metrics.bounds.width(); height=metrics.bounds.height()
   val insets=metrics.windowInsets.getInsetsIgnoringVisibility(android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.displayCutout())
   left=insets.left.toFloat(); top=insets.top.toFloat(); right=insets.right.toFloat(); bottom=insets.bottom.toFloat()
  } else {
   val metrics=android.util.DisplayMetrics()
   @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
   width=metrics.widthPixels; height=metrics.heightPixels
   top=32*density; bottom=48*density
  }
  val r=RectF(max(left,config.side*density),max(top,config.top*density),width-max(right,config.side*density),height-max(bottom,config.bottom*density))
  return if(r.width()>=80*density && r.height()>=80*density) r else null
 }
 fun perform(mode: ControlMode, motion: Motion, config: ControlSettings, done: (Boolean)->Unit): Boolean {
  if(blockReason(config.mapsOnly)!=null) return false
  val r=safeRect(config) ?: run { graph.diagnostics.fail("Márgenes demasiado grandes para esta pantalla"); return false }
  val plan=GesturePlanner.plan(mode,motion,config,SafeBounds(r.left,r.top,r.right,r.bottom),resources.displayMetrics.density) ?: return false
  val builder=GestureDescription.Builder()
  val duration=plan.durationMs
  plan.strokes.forEach { stroke ->
   val path=Path().apply { moveTo(stroke.x1,stroke.y1); lineTo(stroke.x2,stroke.y2) }
   builder.addStroke(GestureDescription.StrokeDescription(path,0,duration))
  }
  return try {
   val accepted=dispatchGesture(builder.build(),object: GestureResultCallback() {
    override fun onCompleted(gestureDescription: GestureDescription?) { done(true) }
    override fun onCancelled(gestureDescription: GestureDescription?) { done(false) }
   },Handler(Looper.getMainLooper()))
   if(accepted) graph.diagnostics.lastGesture.value="${mode.name} · ${duration} ms · x=${"%.2f".format(motion.x)} y=${"%.2f".format(motion.y)}"
   accepted
  } catch(e: Exception) { graph.diagnostics.fail("Gesto rechazado: ${e.message}"); false }
 }
 override fun onInterrupt() { graph.stop("Accesibilidad interrumpida") }
 override fun onUnbind(intent: android.content.Intent?): Boolean { detach(); return super.onUnbind(intent) }
 override fun onDestroy() { detach(); super.onDestroy() }
 private fun detach() {
  if(instance!==this) return
  instance=null; graph.accessibility.value=false; graph.engine.accessibilityLost()
 }
}

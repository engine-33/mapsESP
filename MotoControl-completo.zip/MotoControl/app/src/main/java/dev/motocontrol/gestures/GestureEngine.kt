package dev.motocontrol.gestures

import android.os.SystemClock
import dev.motocontrol.AppGraph
import dev.motocontrol.accessibility.MotoAccessibilityService
import dev.motocontrol.ble.JoystickFrame
import dev.motocontrol.input.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.*

/** One latest sample and one in-flight gesture. No command queue. All access on main. */
class GestureEngine(private val graph: AppGraph) {
 val armed=MutableStateFlow(false)
 val mode=MutableStateFlow(ControlMode.MAPA)
 val reason=MutableStateFlow("Control detenido")
 private val processor=JoystickProcessor()
 private var motion=Motion()
 private var lastInput=0L
 private var lastDispatch=0L
 private var busy=false
 private var gestureSerial=0L
 private var epoch=0
 private var stale=true
 fun input(frame: JoystickFrame) {
  lastInput=SystemClock.elapsedRealtime(); stale=false
  motion=processor.process(frame,graph.settings.state.value,lastInput); mode.value=processor.mode
 }
 fun arm(): Boolean {
  val service=MotoAccessibilityService.instance
  if(service==null) { reason.value="Habilita accesibilidad"; return false }
  if(!graph.serviceRunning.value) { reason.value="Inicia la sesión primero"; return false }
  if(!graph.demo.value && !graph.ble.connected.value) { reason.value="Conecta el ESP32 o inicia una sesión demo"; return false }
  motion=Motion(); processor.reset(); stale=true; lastInput=0L
  armed.value=true; reason.value="Esperando datos nuevos"; graph.diagnostics.log("Control activado manualmente")
  return true
 }
 fun stop(message: String) {
  armed.value=false; motion=Motion(); processor.reset(); stale=true; lastInput=0L
  // Public accessibility API has no touch-free cancel. Do not inject a synthetic tap.
  // Keep busy until callback: even a stop/rearm must not overlap the current gesture.
  epoch++; reason.value=message
 }
 fun accessibilityLost() { gestureSerial++; busy=false; stop("Accesibilidad desconectada") }
 fun tick() {
  graph.sampleRate()
  if(!armed.value) return
  val now=SystemClock.elapsedRealtime()
  if(now-lastInput>=500 || stale) {
   if(!stale) { motion=Motion(); processor.reset(); stale=true; reason.value="Sin señal válida · joystick en reposo" }
   return
  }
  if(!graph.demo.value && !graph.ble.connected.value) { stop("BLE desconectado"); return }
  val service=MotoAccessibilityService.instance ?: run { stop("Accesibilidad desconectada"); return }
  val blocked=service.blockReason(graph.settings.state.value.mapsOnly)
  if(blocked!=null) { reason.value=blocked; return }
  if(busy || now-lastDispatch < (1000f/graph.settings.state.value.frequency).toLong()) return
  val intensity=if(mode.value==ControlMode.MAPA) hypot(motion.x,motion.y) else abs(motion.y)
  if(intensity<.015f) { reason.value="En reposo"; return }
  busy=true; lastDispatch=now; val token=epoch; val id=++gestureSerial
  val accepted=service.perform(mode.value,motion,graph.settings.state.value) { success ->
   if(id!=gestureSerial) return@perform
   busy=false
   if(token==epoch && armed.value) reason.value=if(success) "Control activo" else "Gesto cancelado por Android"
  }
  if(!accepted) { busy=false; reason.value="Android rechazó el gesto" }
 }
}

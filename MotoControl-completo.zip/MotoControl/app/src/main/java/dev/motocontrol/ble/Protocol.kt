package dev.motocontrol.ble

import java.util.UUID

data class JoystickFrame(val x: Int, val y: Int, val pressed: Boolean)
object BleProtocol {
 val SERVICE: UUID = UUID.fromString("6d6f746f-6374-4c00-8000-000000000001")
 val INPUT: UUID = UUID.fromString("6d6f746f-6374-4c00-8000-000000000002")
 val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
 fun parse(line: String): JoystickFrame? {
  val f = line.trimEnd('\r').split(',')
  val base = if(f.size == 5 && f[0] == "V1" && f[1] == "JOY") 2
   else if(f.size == 4 && f[0] == "JOY") 1 else return null
  val x = f[base].toIntOrNull() ?: return null
  val y = f[base+1].toIntOrNull() ?: return null
  val button = f[base+2].toIntOrNull() ?: return null
  if(x !in 0..4095 || y !in 0..4095 || button !in 0..1) return null
  return JoystickFrame(x,y,button == 1)
 }
}
/** Newline framing: bounded storage, survives fragmented and concatenated notifications. */
class FrameDecoder(private val frame: (JoystickFrame, String) -> Unit, private val invalid: () -> Unit) {
 private val buffer = StringBuilder()
 private var dropping = false
 fun reset() { buffer.clear(); dropping = false }
 fun accept(bytes: ByteArray) {
  for(b in bytes) {
   val c = (b.toInt() and 255).toChar()
   if(c == '\n') {
    if(!dropping && buffer.isNotEmpty()) {
     val line = buffer.toString(); val parsed = BleProtocol.parse(line)
     if(parsed != null) frame(parsed,line) else invalid()
    }
    reset()
   } else if(!dropping) {
    if(buffer.length >= 80 || c.code !in 13..126 || (c.code in 14..31)) { dropping = true; buffer.clear(); invalid() }
    else buffer.append(c)
   }
  }
 }
}

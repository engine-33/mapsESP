package dev.motocontrol.gestures

import dev.motocontrol.input.*
import dev.motocontrol.settings.ControlSettings
import kotlin.math.*

data class SafeBounds(val left: Float,val top: Float,val right: Float,val bottom: Float) {
 val width get()=right-left
 val height get()=bottom-top
 val cx get()=(left+right)/2
 val cy get()=(top+bottom)/2
}
data class TouchStroke(val x1: Float,val y1: Float,val x2: Float,val y2: Float)
data class GesturePlan(val durationMs: Long,val strokes: List<TouchStroke>)
object GesturePlanner {
 fun plan(mode: ControlMode,motion: Motion,s: ControlSettings,r: SafeBounds,density: Float): GesturePlan? {
  if(density<=0 || r.width<80*density || r.height<80*density) return null
  val duration=(if(mode==ControlMode.MAPA) s.duration else s.zoomDuration).toLong().coerceIn(60,350)
  fun stroke(x1: Float,y1: Float,x2: Float,y2: Float)=TouchStroke(x1.coerceIn(r.left,r.right),y1.coerceIn(r.top,r.bottom),x2.coerceIn(r.left,r.right),y2.coerceIn(r.top,r.bottom))
  val strokes=if(mode==ControlMode.MAPA) {
   val intensity=hypot(motion.x,motion.y).coerceIn(.001f,1f)
   val distance=(s.minSpeed+(s.maxSpeed-s.minSpeed)*intensity)*density
   val dx=(motion.x/intensity*distance).coerceIn(-r.width*.8f,r.width*.8f)
   val dy=(motion.y/intensity*distance).coerceIn(-r.height*.8f,r.height*.8f)
   listOf(stroke(r.cx-dx/2,r.cy-dy/2,r.cx+dx/2,r.cy+dy/2))
  } else {
   val radius=min(r.width,r.height)*.28f
   val delta=(abs(motion.y)*s.zoomSensitivity*s.zoomAmplitude*density).coerceIn(1f,radius*.8f)
   val start=if(motion.y<0) radius-delta/2 else radius+delta/2
   val end=if(motion.y<0) radius+delta/2 else radius-delta/2
   listOf(stroke(r.cx-start,r.cy,r.cx-end,r.cy),stroke(r.cx+start,r.cy,r.cx+end,r.cy))
  }
  return GesturePlan(duration,strokes)
 }
}

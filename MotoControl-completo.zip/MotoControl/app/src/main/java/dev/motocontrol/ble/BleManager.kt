@file:Suppress("MissingPermission", "DEPRECATION", "OVERRIDE_DEPRECATION")
package dev.motocontrol.ble

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.pm.PackageManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.*
import dev.motocontrol.AppGraph
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.min

data class FoundDevice(val address: String, val name: String, val rssi: Int)
class BleManager(private val graph: AppGraph) {
 private val handler = Handler(Looper.getMainLooper())
 private val manager = graph.app.getSystemService(BluetoothManager::class.java)
 val devices = MutableStateFlow<List<FoundDevice>>(emptyList())
 val status = MutableStateFlow("Desconectado")
 val connected = MutableStateFlow(false)
 val bluetoothOn = MutableStateFlow(false)
 val scanning = MutableStateFlow(false)
 val deviceName = MutableStateFlow("")
 private var gatt: BluetoothGatt? = null
 private var scanner: BluetoothLeScanner? = null
 private var desired = ""
 private var attempt = 0
 private var generation = 0
 private var scanGeneration = 0
 private val decoder = FrameDecoder({ frame,line -> graph.receive(frame,line,false) }, { graph.diagnostics.fail("Trama BLE inválida o demasiado larga") })
 private val radioReceiver=object: BroadcastReceiver() {
  override fun onReceive(context: Context?,intent: Intent?) {
   refreshBluetooth()
   if(!bluetoothOn.value && gatt!=null) failure("Bluetooth apagado")
  }
 }
 init {
  refreshBluetooth()
  val filter=IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED)
  if(Build.VERSION.SDK_INT>=33) graph.app.registerReceiver(radioReceiver,filter,Context.RECEIVER_EXPORTED)
  else graph.app.registerReceiver(radioReceiver,filter)
 }
 fun refreshBluetooth() { bluetoothOn.value=enabled() }
 fun permitted(): Boolean = if(Build.VERSION.SDK_INT >= 31) {
  graph.app.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED &&
  graph.app.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED
 } else graph.app.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
 fun enabled(): Boolean = try { permitted() && manager?.adapter?.isEnabled == true } catch(_: SecurityException) { false }
 private val scanCallback = object: ScanCallback() {
  override fun onScanResult(type: Int, result: ScanResult) { handler.post {
   if(!scanning.value) return@post
   try {
    val d = FoundDevice(result.device.address,result.scanRecord?.deviceName ?: result.device.name ?: "Sin nombre",result.rssi)
    devices.value = (devices.value.filterNot { it.address==d.address }+d).takeLast(60).sortedByDescending { it.rssi }
   } catch(_: SecurityException) { failure("Permiso Bluetooth revocado") }
  } }
  override fun onScanFailed(code: Int) { handler.post { stopScan(); graph.diagnostics.fail("Escaneo falló: $code") } }
 }
 fun scan(nameOnly: Boolean) {
  stopScan()
  if(!enabled()) { graph.diagnostics.fail("Activa Bluetooth y concede permisos. En Android 8–11 activa también Ubicación."); return }
  devices.value=emptyList()
  try {
   scanner=manager.adapter.bluetoothLeScanner
   if(scanner==null) { graph.diagnostics.fail("Este dispositivo no ofrece escáner BLE"); return }
   scanning.value=true
   val filters = if(nameOnly) listOf(ScanFilter.Builder().setDeviceName("MotoControl ESP32").build()) else emptyList()
   scanner?.startScan(filters, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),scanCallback)
   graph.diagnostics.log("Escaneo iniciado (15 s)")
   val token=++scanGeneration
   handler.postDelayed({ if(token==scanGeneration) stopScan() },15000)
  } catch(e: Exception) { stopScan(); graph.diagnostics.fail("No se pudo escanear: ${e.message}") }
 }
 fun stopScan() {
  scanGeneration++
  try { scanner?.stopScan(scanCallback) } catch(_: SecurityException) { }
  scanning.value=false; scanner=null
 }
 fun connect(address: String) {
  disconnect(); graph.demo.value=false; desired=address; attempt=0
  open()
 }
 fun reconnectLast() {
  val config = graph.settings.state.value
  if(desired.isEmpty() && !connected.value && config.reconnect && config.lastAddress.isNotEmpty()) {
   desired=config.lastAddress; attempt=0; open()
  }
 }
 private fun open() {
  if(desired.isEmpty()) return
  if(!enabled()) { failure("Bluetooth apagado o permisos ausentes"); return }
  stopScan(); closeGatt(); decoder.reset()
  status.value="Conectando…"
  val token=++generation
  try {
   gatt=manager.adapter.getRemoteDevice(desired).connectGatt(graph.app,false,callback,BluetoothDevice.TRANSPORT_LE)
   handler.postDelayed({ if(token==generation && !connected.value) failure("Tiempo de conexión agotado") },12000)
  } catch(e: Exception) { failure("Conexión fallida: ${e.message}") }
 }
 private fun closeGatt() {
  val old=gatt; gatt=null
  try { old?.disconnect(); old?.close() } catch(_: SecurityException) { }
  connected.value=false
 }
 fun disconnect() {
  desired=""; generation++; closeGatt(); stopScan(); decoder.reset()
  status.value="Desconectado"; deviceName.value=""; graph.stop("BLE desconectado")
 }
 private fun failure(message: String) {
  generation++; closeGatt(); decoder.reset(); graph.stop("Pérdida de conexión BLE")
  graph.diagnostics.fail(message); status.value=message
  if(desired.isNotEmpty() && graph.settings.state.value.reconnect && graph.serviceRunning.value) {
   val delay=min(30000L,1000L shl min(attempt++,5)); val token=generation
   status.value="Reconectando en ${delay/1000} s · $message"
   handler.postDelayed({ if(token==generation && desired.isNotEmpty() && graph.settings.state.value.reconnect) open() },delay)
  }
 }
 private fun onGatt(g: BluetoothGatt, work: () -> Unit) { handler.post { if(g===gatt) work() } }
 private val callback = object: BluetoothGattCallback() {
  override fun onConnectionStateChange(g: BluetoothGatt, code: Int, state: Int) = onGatt(g) {
   if(code!=BluetoothGatt.GATT_SUCCESS || state==BluetoothProfile.STATE_DISCONNECTED) { failure("GATT desconectado ($code)"); return@onGatt }
   if(state==BluetoothProfile.STATE_CONNECTED) {
    status.value="Descubriendo servicio…"
    try { if(!g.discoverServices()) failure("No se pudo descubrir GATT") } catch(_: SecurityException) { failure("Permiso Bluetooth revocado") }
   }
  }
  override fun onServicesDiscovered(g: BluetoothGatt, code: Int) = onGatt(g) {
   if(code!=BluetoothGatt.GATT_SUCCESS) { failure("Error al descubrir servicios: $code"); return@onGatt }
   val characteristic=g.getService(BleProtocol.SERVICE)?.getCharacteristic(BleProtocol.INPUT)
   val descriptor=characteristic?.getDescriptor(BleProtocol.CCCD)
   if(characteristic==null || descriptor==null || characteristic.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY == 0) {
    failure("Servicio, característica NOTIFY o CCCD ausente"); return@onGatt
   }
   try {
    if(!g.setCharacteristicNotification(characteristic,true)) { failure("No se pudo habilitar NOTIFY"); return@onGatt }
    val ok = if(Build.VERSION.SDK_INT>=33) g.writeDescriptor(descriptor,BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)==BluetoothStatusCodes.SUCCESS
     else { descriptor.value=BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; g.writeDescriptor(descriptor) }
    if(!ok) failure("No se pudo escribir CCCD")
   } catch(_: SecurityException) { failure("Permiso Bluetooth revocado") }
  }
  override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, code: Int) = onGatt(g) {
   if(descriptor.uuid!=BleProtocol.CCCD) return@onGatt
   if(code!=BluetoothGatt.GATT_SUCCESS) { failure("Suscripción rechazada: $code"); return@onGatt }
   connected.value=true; attempt=0; status.value="Conectado · notificaciones activas"
   try { deviceName.value=g.device.name ?: g.device.address } catch(_: SecurityException) { deviceName.value=desired }
   graph.scope.launch { graph.settings.remember(desired) }
   graph.diagnostics.log("BLE conectado: ${deviceName.value}. Activa el control manualmente.")
  }
  override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
   if(characteristic.uuid==BleProtocol.INPUT) { val copy=value.copyOf(); onGatt(g) { if(connected.value) decoder.accept(copy) } }
  }
  override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
   if(Build.VERSION.SDK_INT<33) onCharacteristicChanged(g,characteristic,characteristic.value ?: return)
  }
 }
}

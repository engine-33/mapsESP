package dev.motocontrol

import dev.motocontrol.ble.JoystickFrame
import dev.motocontrol.input.*
import dev.motocontrol.settings.ControlSettings
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.hypot

class JoystickProcessorTest {
 private val settings=ControlSettings(smoothing=0f)
 @Test fun centerAndDeadZoneStopImmediately() {
  val p=JoystickProcessor()
  assertEquals(Motion(),p.process(JoystickFrame(2100,2090,false),settings,1000))
  p.process(JoystickFrame(4095,0,false),settings.copy(smoothing=.8f),1033)
  assertEquals(Motion(),p.process(JoystickFrame(2048,2048,false),settings.copy(smoothing=.8f),1066))
 }
 @Test fun diagonalIsNormalized() {
  val m=JoystickProcessor().process(JoystickFrame(4095,4095,false),settings,1000)
  assertEquals(1f,hypot(m.x,m.y),.001f); assertTrue(m.x>0); assertEquals(m.x,m.y,.001f)
 }
 @Test fun inclinationControlsMagnitude() {
  val small=JoystickProcessor().process(JoystickFrame(2700,2048,false),settings,1000)
  val large=JoystickProcessor().process(JoystickFrame(4000,2048,false),settings,1000)
  assertTrue(large.x>small.x); assertTrue(small.x>0)
 }
 @Test fun independentAxisInversions() {
  val normal=JoystickProcessor().process(JoystickFrame(3000,3500,false),settings,1000)
  val inverted=JoystickProcessor().process(JoystickFrame(3000,3500,false),settings.copy(invertX=true),1000)
  assertEquals(-normal.x,inverted.x,.001f); assertEquals(normal.y,inverted.y,.001f)
 }
 @Test fun buttonTogglesOnlyOnDebouncedRisingEdge() {
  val p=JoystickProcessor()
  p.process(JoystickFrame(2048,2048,true),settings,1000); assertEquals(ControlMode.ZOOM,p.mode)
  p.process(JoystickFrame(2048,2048,true),settings,1500); assertEquals(ControlMode.ZOOM,p.mode)
  p.process(JoystickFrame(2048,2048,false),settings,1510)
  p.process(JoystickFrame(2048,2048,true),settings,1530); assertEquals(ControlMode.MAPA,p.mode)
  p.process(JoystickFrame(2048,2048,false),settings,1540)
  p.process(JoystickFrame(2048,2048,true),settings,1550); assertEquals(ControlMode.MAPA,p.mode)
 }
 @Test fun smoothingReducesInitialJump() {
  val p=JoystickProcessor()
  val first=p.process(JoystickFrame(4095,2048,false),settings.copy(smoothing=.8f),1000)
  val second=p.process(JoystickFrame(4095,2048,false),settings.copy(smoothing=.8f),1033)
  assertTrue(first.x in .1f.. .3f); assertTrue(second.x>first.x)
 }
}

package dev.motocontrol

import dev.motocontrol.ble.*
import org.junit.Assert.*
import org.junit.Test

class ProtocolTest {
 @Test fun validVersionedAndLegacyMessages() {
  assertEquals(JoystickFrame(4095,0,true),BleProtocol.parse("V1,JOY,4095,0,1"))
  assertEquals(JoystickFrame(2048,2048,false),BleProtocol.parse("JOY,2048,2048,0\r"))
 }
 @Test fun rejectsMalformedOrOutOfRangeMessages() {
  listOf("V2,JOY,1,2,0","JOY,-1,2048,0","JOY,4096,0,0","JOY,1,2,2","JOY,1,2","JOY,1,2,0,7","JOY,NaN,2,0","V1,BAT,80").forEach { assertNull(it,BleProtocol.parse(it)) }
 }
 @Test fun reconstructsFragmentsAndMultipleFrames() {
  val frames=mutableListOf<JoystickFrame>(); var invalid=0
  val decoder=FrameDecoder({ f,_ -> frames.add(f) },{invalid++})
  decoder.accept("V1,JOY,20".toByteArray()); assertTrue(frames.isEmpty())
  decoder.accept("48,2048,0\nJOY,0,4095,1\nV1,JOY,1,".toByteArray())
  assertEquals(2,frames.size)
  decoder.accept("2,0\n".toByteArray()); assertEquals(3,frames.size); assertEquals(0,invalid)
 }
 @Test fun oversizeFrameDropsUntilDelimiterAndRecovers() {
  val frames=mutableListOf<JoystickFrame>(); var invalid=0
  val decoder=FrameDecoder({ f,_ -> frames.add(f) },{invalid++})
  decoder.accept(("x".repeat(300)+"JOY,1,2,0\nV1,JOY,3,4,0\n").toByteArray())
  assertEquals(1,invalid); assertEquals(listOf(JoystickFrame(3,4,false)),frames)
 }
 @Test fun decoderResetDiscardsOldConnectionFragment() {
  val frames=mutableListOf<JoystickFrame>()
  val decoder=FrameDecoder({ f,_ -> frames.add(f) },{})
  decoder.accept("V1,JOY,1,".toByteArray()); decoder.reset()
  decoder.accept("2,0\nJOY,5,6,0\n".toByteArray())
  assertEquals(listOf(JoystickFrame(5,6,false)),frames)
 }
 @Test fun nonAsciiFrameRejectedAndRecovers() {
  val frames=mutableListOf<JoystickFrame>(); var invalid=0
  val decoder=FrameDecoder({ f,_ -> frames.add(f) },{invalid++})
  decoder.accept(byteArrayOf(0xff.toByte(),10)); decoder.accept("JOY,1,2,0\n".toByteArray())
  assertEquals(1,invalid); assertEquals(1,frames.size)
 }
}

package dev.motocontrol

import dev.motocontrol.gestures.*
import dev.motocontrol.input.*
import dev.motocontrol.settings.ControlSettings
import org.junit.Assert.*
import org.junit.Test

class GesturePlannerTest {
 private val bounds=SafeBounds(40f,100f,500f,800f)
 @Test fun panAndZoomStayInsideSafeRegion() {
  val s=ControlSettings(maxSpeed=300f,zoomAmplitude=180f,zoomSensitivity=2f)
  for(mode in ControlMode.entries) for(x in -10..10) for(y in -10..10) {
   val plan=GesturePlanner.plan(mode,Motion(x/10f,y/10f),s,bounds,2f)!!
   plan.strokes.forEach { stroke ->
    assertTrue(stroke.x1 in bounds.left..bounds.right); assertTrue(stroke.x2 in bounds.left..bounds.right)
    assertTrue(stroke.y1 in bounds.top..bounds.bottom); assertTrue(stroke.y2 in bounds.top..bounds.bottom)
   }
  }
 }
 @Test fun zoomUpSeparatesAndZoomDownConverges() {
  val up=GesturePlanner.plan(ControlMode.ZOOM,Motion(0f,-1f),ControlSettings(),bounds,1f)!!
  val down=GesturePlanner.plan(ControlMode.ZOOM,Motion(0f,1f),ControlSettings(),bounds,1f)!!
  assertEquals(2,up.strokes.size)
  fun distance(p: GesturePlan,end: Boolean): Float = if(end) p.strokes[1].x2-p.strokes[0].x2 else p.strokes[1].x1-p.strokes[0].x1
  assertTrue(distance(up,true)>distance(up,false)); assertTrue(distance(down,true)<distance(down,false))
 }
 @Test fun tooSmallSafeRegionIsRejected() {
  assertNull(GesturePlanner.plan(ControlMode.MAPA,Motion(1f,0f),ControlSettings(),SafeBounds(0f,0f,50f,200f),1f))
 }
 @Test fun durationCannotExceedStopBound() {
  assertEquals(350L,GesturePlanner.plan(ControlMode.MAPA,Motion(1f,0f),ControlSettings(duration=2000f),bounds,1f)!!.durationMs)
  assertEquals(60L,GesturePlanner.plan(ControlMode.ZOOM,Motion(0f,1f),ControlSettings(zoomDuration=1f),bounds,1f)!!.durationMs)
 }
 @Test fun diagonalPanUsesOneStrokeWithBothAxes() {
  val plan=GesturePlanner.plan(ControlMode.MAPA,Motion(.7f,-.7f),ControlSettings(),bounds,1f)!!
  assertEquals(1,plan.strokes.size)
  assertTrue(plan.strokes[0].x2>plan.strokes[0].x1); assertTrue(plan.strokes[0].y2<plan.strokes[0].y1)
 }
}

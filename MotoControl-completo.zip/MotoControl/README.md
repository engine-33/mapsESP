# MotoControl · MVP Android nativo

Control BLE para ESP32 y Google Maps. Kotlin, Compose Material 3, MVVM sencilla, DataStore y AccessibilityService. Sin Internet, cuentas, root ni lectura del contenido de aplicaciones.

## Abrir y compilar

1. Abre esta carpeta en Android Studio compatible con AGP 8.13 (Otter o posterior).
2. Instala Android SDK Platform 36 y Build Tools 36.0.0. Usa JDK 17 o 21 para Gradle.
3. Android Studio genera `local.properties` apuntando a tu SDK. No uses rutas del equipo de otra persona.
4. Ejecuta `./gradlew assembleDebug testDebugUnitTest lintDebug` (Windows: `gradlew.bat`).
5. APK: `app/build/outputs/apk/debug/app-debug.apk`. Instalación por Android Studio o transfiriendo el APK al teléfono y autorizando ese instalador. La firma debug es solo para desarrollo.

Versiones fijadas: Gradle 8.13, AGP 8.13.2, Kotlin/Compose Compiler 2.2.21, Compose BOM 2025.10.01, Activity 1.11.0, Lifecycle 2.9.4, DataStore 1.1.7, Coroutines 1.10.2. `compileSdk` y `targetSdk` 36 (Android 16); `minSdk` 26 (Android 8) cubre gestos multitáctiles y APIs modernas con compatibilidad explícita de permisos BLE. No se requiere red para funcionar; Gradle necesita descargar dependencias durante la primera compilación.

## Primera configuración

- Instala y abre MotoControl con la moto detenida.
- Pulsa **Accesibilidad** y habilita «MotoControl · gestos» manualmente. La descripción explica su funcionamiento. En Android 13+, una instalación por APK puede requerir permitir «ajustes restringidos» desde la información de la app; depende del fabricante y del instalador.
- Inicia **sesión BLE** o **Probar sin ESP32**. Concede Bluetooth (Android 12+) o Ubicación precisa (Android 8–11). En Android 8–11 también activa la ubicación del sistema para escanear BLE. La app no calcula ni almacena ubicación.
- Android 13+ pide notificaciones para mostrar la sesión. Si las rechazas, Android puede mostrar el servicio solo en su administrador de tareas. El rechazo de notificaciones no impide BLE.
- Todo arranca detenido. Pulsa **Activar control explícitamente** después de preparar el dispositivo o la demo.
- El filtro **Solo Google Maps** está activado inicialmente. Abre Google Maps para que se identifique la ventana activa; tras habilitar accesibilidad por primera vez puede ser necesario salir y volver a Maps.
- **Detener control** impide nuevos gestos. **Cerrar sesión y desconectar** termina también el servicio BLE. La notificación persistente permite detener la sesión fuera de la app.

## Prueba sin hardware

1. Inicia **Probar sin ESP32** y habilita accesibilidad.
2. Para probar sobre MotoControl, ve a Ajustes y desactiva **Solo Google Maps**; el control se detiene al cambiar esta opción. La lista de apps permitidas se amplía únicamente a MotoControl, nunca a otras apps.
3. Vuelve a Control, activa explícitamente el control y arrastra el joystick virtual. Soltarlo emite reposo inmediato. Los gestos locales pueden interactuar con la propia interfaz; detén el control cuando termines.
4. Pulsa **cambiar MAPA / ZOOM**: emite el mismo flanco de botón que el ESP32. En zoom, arriba separa los dedos y abajo los acerca. Mantener el botón físico no repite el cambio; hay antirrebote de 250 ms.
5. Para probar Maps, deja la restricción activada. Con control activo y sesión demo, elige una prueba de dirección/zoom con espera de 3 s y pulsa **Abrir Google Maps**. El comando se mantiene durante aproximadamente 1 s y termina en reposo. No se activa el control automáticamente.
6. El joystick virtual solo envía mientras está pulsado en la pantalla. Al salir de la Activity se libera; las pruebas programadas explícitamente pueden completarse sobre Maps. Cada prueba usa exactamente `AppGraph.receive → GestureEngine → JoystickProcessor → dispatchGesture`, igual que BLE.

## ESP32

Consulta [docs/PROTOCOLO_BLE.md](docs/PROTOCOLO_BLE.md). El ESP32 debe anunciar el servicio personalizado, incluir CCCD y enviar notificaciones con salto de línea. La conexión no depende del emparejamiento clásico Bluetooth.

1. Inicia sesión BLE; escanea (15 s máximo).
2. Si no se anuncia el nombre exacto, desactiva el filtro por nombre.
3. Selecciona el dispositivo. «Conectado» aparece solo después de habilitar correctamente sus notificaciones GATT.
4. Comprueba X/Y y tasa de mensajes en Diagnóstico; objetivo 20–30 Hz.
5. Activa el control y abre Maps. La reconexión usa 1, 2, 4, 8, 16 y hasta 30 s entre intentos. Solo funciona durante una sesión iniciada por el usuario; recuerda la dirección, no crea conexiones desde el arranque del teléfono.
6. Una desconexión desarma el control. La reconexión no lo vuelve a activar. Desconectar manualmente cancela los reintentos de esa conexión.

## Movimiento y seguridad

- Coordenadas crudas de 0–4095, centro 2048. Se aplica zona muerta radial, normalización de diagonales, sensibilidad, inversiones y filtro de suavizado. Un dato dentro de la zona muerta elimina inmediatamente el movimiento filtrado.
- La amplitud de arrastre en dp/gesto crece con la inclinación. La velocidad percibida depende de amplitud, duración y frecuencia; el límite de frecuencia es máximo, no una promesa de cadencia. Android ejecuta un gesto cada vez.
- El eje Y positivo arrastra hacia abajo; invierte Y si tu joystick usa la convención opuesta. El desplazamiento geográfico del mapa depende de cómo Maps interprete el arrastre.
- Arrastres desde el centro de una región segura y pinzas con dos trazos simultáneos. Los extremos se mantienen dentro de esa región. Cada gesto libera el contacto al terminar.
- Región recalculada en cada gesto con tamaño real, barras del sistema y recortes en API 30+. En API 26–29 se añaden mínimos conservadores para barras. Los márgenes de usuario están en dp. Con márgenes que dejen poco espacio no se envían gestos. En pantallas plegables, multiventana y barras particulares de fabricantes, valida y ajusta márgenes antes de usarlo.
- No hay cola: se mantiene solo la última muestra y un único gesto en curso. No se despacha el siguiente hasta recibir el callback de finalización/cancelación.
- Sin mensaje válido durante 500 ms se pone el joystick en reposo. El bucle comprueba cada 25 ms con control activo (latencia de comprobación hasta ~25 ms más programación del sistema). Tramas corruptas no renuevan el timeout. Al volver a centro tampoco se acumulan movimientos.
- Android no ofrece un método público para cancelar sin contacto un `dispatchGesture` en curso. Parada, timeout o desconexión suprimen inmediatamente los siguientes gestos; el actual puede concluir dentro de su duración configurada (máximo 350 ms). No se inyecta un toque artificial para cancelarlo. Una parada seguida de activación tampoco solapa gestos.
- Se comprueban pantalla encendida, bloqueo y paquete activo antes de cada gesto. Accesibilidad solo recibe eventos de ventanas y nombre del paquete: `canRetrieveWindowContent=false`. No inspecciona nodos, textos, contraseñas ni contenido personal.
- La identificación del primer plano por eventos puede fallar con overlays, pantalla dividida o fabricantes particulares. Estado desconocido bloquea el control. Si aparece «aplicación activa desconocida», cierra overlays y vuelve a abrir Maps. Los eventos de cambio de ventana no ofrecen una prueba absoluta de la superficie que recibe los toques: **usa una sola app en pantalla y no uses superposiciones durante el control**. El MVP no promete aislamiento completo frente a ventanas flotantes de terceros.
- Solo se permiten Maps y, si desactivas la restricción, MotoControl para pruebas. No se autorizan Ajustes, System UI, instaladores ni otras apps.
- Maps puede recentrar automáticamente durante una navegación; no se garantiza que cada versión de Maps permita desplazar o ampliar todas sus vistas. Ajusta los márgenes para evitar sus controles. No hay APIs privadas para controlar Maps.

## Segundo plano y batería

`ControlService` usa `foregroundServiceType=connectedDevice`, permiso de foreground service y permiso específico en Android 14+. Se inicia exclusivamente desde la Activity visible tras concesión de permisos. Para el tipo conectado, Android 14+ requiere permiso Bluetooth en tiempo de ejecución, también para mantener una sesión de demostración. Un emulador sin radio puede probar gestos si permite conceder esos permisos; no puede simular un ESP32 real.

La notificación persistente abre la app o detiene sesión y BLE. El servicio es `START_NOT_STICKY`: no se reinicia y rearma tras una muerte de proceso. Al quitar la tarea de recientes se cierra la sesión deliberadamente. Al ir a Maps normalmente permanece la conexión. No hay arranque automático, wakelock permanente ni peticiones de exención de batería. El sistema, Doze y fabricantes pueden suspender o terminar la app; abre MotoControl y reinicia manualmente si sucede. Un teléfono bloqueado nunca recibe gestos.

## Estructura

- `ble/`: central nativo, escaneo, GATT serializado, CCCD, timeouts y backoff; decoder de tramas acotado.
- `input/`: normalización y procesamiento independientes del transporte.
- `gestures/`: armado explícito, timeout y planificador sin cola.
- `accessibility/`: comprobaciones de pantalla y primer plano, región segura y gestos reales.
- `service/`: foreground service y notificación con parada.
- `settings/`: DataStore Preferences y rangos de valores.
- `diagnostics/`: telemetría y registro de hasta 120 eventos en memoria.
- `ui/`: Compose y ViewModel. La demo usa el motor real.

Solo se persiste configuración y dirección BLE del último dispositivo. No hay historial personal, exportación remota ni permiso `INTERNET`. Direcciones BLE aleatorias que cambian tras reiniciar el ESP32 pueden requerir un nuevo escaneo manual. BLE no autentica el emisor en esta versión: selecciona un periférico propio; no se ha implementado cifrado/autenticación a nivel de aplicación.

## Validación

Consulta [docs/VALIDACION.md](docs/VALIDACION.md) para los resultados del entorno y el checklist real. Pruebas JVM cubren mensajes fragmentados/corruptos, límites, recuperación del decoder, zona muerta, diagonales, intensidad, inversión, suavizado y antirrebote.

La compilación y las pruebas unitarias no prueban Bluetooth físico, gestos sobre Maps, navegación activa ni variaciones de Android. Esas verificaciones requieren un teléfono y un ESP32. No se da por validada la aceptación en hardware sin ejecutarlas.
